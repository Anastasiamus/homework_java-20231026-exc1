import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        LocalDate[] date = new LocalDate[8];

        date[0] = LocalDate.of(1990, 1, 23);
        date[1] = LocalDate.of(1997, 5, 2);
        date[2] = LocalDate.of(2005, 8, 27);
        date[3] = LocalDate.of(2003, 9, 9);
        date[4] = LocalDate.of(2020, 3, 17);
        date[5] = LocalDate.of(2015, 6, 30);
        date[6] = LocalDate.of(1680, 4, 1);
        date[7] = LocalDate.of(1598, 11, 6);

        System.out.println("date");
        System.out.println(Arrays.toString(date));
        System.out.println();
        yearSort(date);
        System.out.println("Year");
        System.out.println(Arrays.toString(date));
        System.out.println();
        daySort(date);
        System.out.println("Month");
        System.out.println(Arrays.toString(date));
    }

    private static void yearSort (LocalDate[]date) {
        int year = date.length;
        for (int i = 0; i < year-1; i++) {
            for (int j = 0; j < year-j-1; j++) {
                if (date[j].getYear()>date[j+1].getYear()){
                    LocalDate temp = date[j];
                    date[j]=date[j+1];
                    date[j+1]=temp;
                }
            }
        }
    }
    private static void daySort(LocalDate[]date){
        int day = date.length;
        for (int i = 0; i < day-i-1; i++) {
            for (int j = 0; j < day-i-1; j++) {
                if (date[j].getDayOfYear()>date[j+1].getDayOfYear()){
                    LocalDate temp =date[j];
                    date[j]=date[j+1];
                    date[j+1]=temp;
                }

            }

        }
    }


    }


// 1 уровень сложности: №1. Сортировка
//1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
// Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день),
// где год, месяц и день – целые числа.
//Выведите массив в консоль.
//2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
//3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
//Сортировку можно выполнить по любому из изученных алгоритмов.
//Пример создания массива с датами: